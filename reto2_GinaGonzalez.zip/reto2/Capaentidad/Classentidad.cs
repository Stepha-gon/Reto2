﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capaentidad
{
    public class Classentidad
    {
        public String nombre { get; set; }
        public String code { get; set; }
        public String autor { get; set; }
        public String editor { get; set; }
        public double price { get; set; }
        public int cant { get; set; }
        public String accion { get; set; }



    }
}
